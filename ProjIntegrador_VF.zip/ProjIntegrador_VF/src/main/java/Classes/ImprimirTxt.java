/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

import Interfaces.Imprimir;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;

/**
 *
 * @author gaby
 */
public class ImprimirTxt {
    
    public void escrever(String cpf, String peca, String turno, String area, String poltrona) { // Método para escrever dados de um novo usuário        
        try {
                // Criar um novo arquivo (ou sobrescrever se já existir)
                File arquivo = new File("Impressão Ingressos.txt");
                FileWriter fw = new FileWriter(arquivo, false);  // O 'false' vai sobrescrever o conteúdo existente
                BufferedWriter bw = new BufferedWriter(fw);

                // Escrever os dados no arquivo
                bw.write("Peça: " + peca);
                bw.newLine();  // Adicionar nova linha
                bw.write("Turno: " + turno);
                bw.newLine();
                bw.write("Área: " + area);
                bw.newLine();
                bw.write("Poltrona: " + poltrona);
                bw.newLine();

                // Fechar o arquivo
                bw.close();
                fw.close();

                // Informar ao usuário que o arquivo foi gerado com sucesso
                

            } catch (IOException e) {
                // Em caso de erro ao criar o arquivo
                e.printStackTrace();
            }
    }
}
