package Classes.BackGuide;

import java.util.Scanner;

public class Menu {
    
    public int inicial(Scanner scanner) {
        System.out.println("_____________________________");
        System.out.println("|       Menu de Ações       |");
        System.out.println("|__________________________ |");
        System.out.println("| 1 - Cadastrar Usuário     |"); //ver validaçao cpf
        System.out.println("| 2 - Comprar Ingresso      |"); //vetores desenvolvidos, testar os loops e
        System.out.println("| 3 - Imprimir Ingresso     |"); //exibir informações
        System.out.println("| 4 - Mostrar Estatística   |"); //desenvolver (olhar no projeto I)
        System.out.println("| 5 - Encerrar o Sistema    |");
        System.out.println("_____________________________"); //arquivo - interface  // tratamento de excessões
        System.out.print("> Digite o número da ação: ");
        return scanner.nextInt();
    }

    public int pecas(Scanner scanner) {
        System.out.println("_______________________________");
        System.out.println("|       Peças em Cartaz       |");
        System.out.println("|_____________________________|");
        System.out.println("| 1 - O Mágico de Oz          |");
        System.out.println("| 2 - Uma Noite na Broadway   |");
        System.out.println("| 3 - Aladdin                 |");
        System.out.println("_______________________________");
        System.out.print("> Digite o número da peça: ");
      return scanner.nextInt();
    }

    public int turno(Scanner scanner) {
        System.out.println("_______________________________");
        System.out.println("|           Sessões           |");
        System.out.println("|_____________________________|");
        System.out.println("| 1 - Manhã                   |");
        System.out.println("| 2 - Tarde                   |");
        System.out.println("| 3 - Noite                   |");
        System.out.println("_______________________________");
        System.out.print("> Digite o número da sessão: ");
        return scanner.nextInt();
    }

    public int area(Scanner scanner) {
        System.out.println("__________________________________");
        System.out.println("|       Área       |    Valor    |");
        System.out.println("|__________________|_____________|");
        System.out.println("| 1 - Plateia A    |  R$ 40,00   |");
        System.out.println("| 2 - Plateia B    |  R$ 60,00   |");
        System.out.println("| 3 - Camarote     |  R$ 80,00   |");
        System.out.println("| 4 - Frisa        |  R$120,00   |");
        System.out.println("| 5 - Balcão Nobre |  R$250,00   |");
        System.out.println("|__________________|_____________|");
        System.out.print("> Digite o número da área: ");
        return scanner.nextInt();
    }


}