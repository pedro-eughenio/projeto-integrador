package Classes.BackGuide;

import java.io.IOException;
import java.util.Scanner;

public class Main {
    private static Scanner scanner = new Scanner(System.in);
    //private static Arquivos arquivos = new Arquivos();
    private static Usuario usuario = new Usuario();
    //private static Areas plateia = new Areas();
    private static Menu menu = new Menu();


    public static void main(String[] args) throws IOException {

        System.out.println("Seja bem vindo(a) à bilheteria do Teatro ABC!");
        int acao;
        do {
            acao = menu.inicial(scanner);
            switch (acao) {
                case 1:
                    cadastrar(); //Cadastrar Usuário
                    System.out.println(""); //quebra de linha (tirar daqui dps)
                    //usuario.exibirCadastro();
                    break;
                case 2:
                    //Comprar Ingresso
                    break;
                case 3:
                    //Imprimir Ingresso
                    break;
                case 4:
//                    Mostrar Estatística
                    break;
                case 5:
                    //Encerrar o Sistema
                    break;
                default:
                    System.out.println("---------------------------------------------");
                    System.out.println("Ação Inválida. \nDigite o número de uma ação disponível.");
                    System.out.println("---------------------------------------------");
                    break;
            }
        } while(acao != 5);
        System.out.println("Encerrando o programa...");
    }

    public static void cadastrar() {//método para cadastrar usuário
        Scanner scanner = new Scanner(System.in);
        System.out.println(""); //quebra de linha
        //usuario.inserirCpf();

        System.out.print("Insira seu nome: ");
        usuario.setNome(scanner.nextLine());

        usuario.inserirTelefone();

        System.out.print("Insira seu endereço: ");
        usuario.setEndereco(scanner.nextLine());

        usuario.inserirNascimento();

        System.out.println("Usuário cadastrado com sucesso no Programa de Fidelidade!");
    }


}