package Classes.BackGuide;

import java.time.LocalDate; //formatação da data
import java.time.format.DateTimeFormatter; //formatação da data
import java.time.format.DateTimeParseException; //formatação da data
import java.util.Scanner;

public class Usuario {

    private String nome;
    private String cpf; //testar verificacao
    private String telefone; //testar | incrementar verificação
    private String endereco;
    private String nascimento; //testar verificaçao

    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getCpf() {
        return cpf;
    }
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
    public String getTelefone() {
        return telefone;
    }
    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
    public String getEndereco() {
        return endereco;
    }
    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }
    public String getNascimento() {
        return nascimento;
    }
    public void setNascimento(String nascimento) {
        this.nascimento = nascimento;
    }

    /*public void inserirCpf() {
        Scanner scanner = new Scanner(System.in);
        //Cpf validacao = new Cpf();

        do {
            System.out.print("Insira seu CPF: ");
            setCpf(scanner.nextLine());

            if(!validacao.validarCPF(getCpf())) {
                System.out.println("CPF inválido. Tente novamente.");
            }
        } while (!validacao.validarCPF(getCpf()));
        System.out.println("CPF inserido com sucesso!");
    } */

    

    public void inserirNascimento() {
        Scanner scanner = new Scanner(System.in);

        do{
            System.out.print("Insira sua data de nascimento (dd/mm/aaaa): ");
            setNascimento(scanner.nextLine());

            try{
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                LocalDate dataNascimento = LocalDate.parse(getNascimento(), formatter);
                System.out.println("Data de nascimento válida");
                break;
            } catch(DateTimeParseException e) {
                System.out.println("Formato de data inválido. Tente novamente usando o formato de dd/mm/aaaa.");
            }
        } while(true);
    }

    public void inserirTelefone() {
        Scanner scanner = new Scanner(System.in);

        do{
            System.out.print("Insira seu telefone (ex: xxxxx-xxxx): ");
            setTelefone(scanner.nextLine());

            telefone = telefone.replaceAll("[^0-9()-]", "");

            if (telefone.length() < 10 || telefone.length() > 15) { //verifica intervalo do telefone
                System.out.println("Número de telefone com tamanho inválido.");
                continue;
            }

            System.out.println("Telefone válido!");
            break;
        } while(true);

    }

    public void comprar() {
        Scanner scanner = new Scanner(System.in);
        Menu menu = new Menu();

        menu.pecas(scanner);
        menu.turno(scanner);
        System.out.print("Quantos ingressos deseja comprar? ");
        int quantidade = scanner.nextInt();

        do{
            menu.area(scanner);
            //mostrar as poltronas
            //pedir para selecionar
        } while(quantidade > 0);
    }

    public void exibirCadastro() { //testar
        System.out.println("----- EXIBIÇÃO DE CADASTRO -----");
        System.out.println("CPF: " + getCpf());
        System.out.println("Nome: " + getNome().toUpperCase());
        System.out.println("Telefone: " + getTelefone());
        System.out.println("Endereco: " + getEndereco().toUpperCase());
        System.out.println("Data de Nascimento: " + getNascimento());
        System.out.println("----------------------------------");
    }
}