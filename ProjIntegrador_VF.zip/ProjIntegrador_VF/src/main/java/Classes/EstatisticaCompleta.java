package Classes;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class EstatisticaCompleta {

    // Método para carregar a planilha
    private static Workbook carregarPlanilha(String caminhoArquivo) throws IOException {
        FileInputStream file = new FileInputStream(new File(caminhoArquivo));
        return new HSSFWorkbook(file);
    }

    public static String pecaMaisVendida(String caminhoArquivo) throws IOException { //retorna a peça mais vendida
        Workbook workbook = carregarPlanilha(caminhoArquivo);
        Sheet sheet = workbook.getSheetAt(0);
        Map<String, Integer> contadorPecas = new HashMap<>();
        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);
            String peca = row.getCell(1).getStringCellValue();
            contadorPecas.put(peca, contadorPecas.getOrDefault(peca, 0) + 1);
        }
        String pecaMaisVendida = null;
        int maxCount = 0;
        for (Map.Entry<String, Integer> entry : contadorPecas.entrySet()) {
            if (entry.getValue() > maxCount) {
                pecaMaisVendida = entry.getKey(); maxCount = entry.getValue();
            }
        } return pecaMaisVendida + " | " + maxCount + " vendas";
    }

    public static String pecaMenosVendida(String caminhoArquivo) throws IOException { //retorna a peça menos vendida
        Workbook workbook = carregarPlanilha(caminhoArquivo);
        Sheet sheet = workbook.getSheetAt(0);
        Map<String, Integer> contadorPecas = new HashMap<>();
        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);
            String peca = row.getCell(1).getStringCellValue();
            contadorPecas.put(peca, contadorPecas.getOrDefault(peca, 0) + 1);
        }
        String pecaMenosVendida = null;
        int minCount = Integer.MAX_VALUE;
        for (Map.Entry<String, Integer> entry : contadorPecas.entrySet()) {
            if (entry.getValue() < minCount) {
                pecaMenosVendida = entry.getKey();
                minCount = entry.getValue();
            }
        } return pecaMenosVendida + " | " + minCount + " vendas";
    }

    public static String turnoMaisOcupado(String caminhoArquivo) throws IOException { //retorna o turno mais ocupado
        Workbook workbook = carregarPlanilha(caminhoArquivo);
        Sheet sheet = workbook.getSheetAt(0);
        Map<String, Integer> contadorTurnos = new HashMap<>();
        // A partir da segunda linha (índice 1)
        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);
            String turno = row.getCell(2).getStringCellValue(); // Coluna 3 (índice 2) armazena o turno
            contadorTurnos.put(turno, contadorTurnos.getOrDefault(turno, 0) + 1);
        }
        String turnoMaisFrequentado = null;
        int maxCount = 0;
        for (Map.Entry<String, Integer> entry : contadorTurnos.entrySet()) {
            if (entry.getValue() > maxCount) {
                turnoMaisFrequentado = entry.getKey();
                maxCount = entry.getValue();
            }
        } return turnoMaisFrequentado + " | " + maxCount + " seleções";
    }

    public static String turnoMenosOcupado(String caminhoArquivo) throws IOException {
        Workbook workbook = carregarPlanilha(caminhoArquivo);
        Sheet sheet = workbook.getSheetAt(0);
        Map<String, Integer> contadorTurnos = new HashMap<>(); // A partir da segunda linha (índice 1)
        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);
            String turno = row.getCell(2).getStringCellValue(); // Coluna 3 (índice 2) armazena o turno
            contadorTurnos.put(turno, contadorTurnos.getOrDefault(turno, 0) + 1);
        }
        String turnoMenosFrequentado = null;
        int minCount = Integer.MAX_VALUE;
        for (Map.Entry<String, Integer> entry : contadorTurnos.entrySet()) {
            if (entry.getValue() < minCount) {
                turnoMenosFrequentado = entry.getKey();
                minCount = entry.getValue();
            }
        } return turnoMenosFrequentado + " | " + minCount + " seleções";
    }


    public static Map<String, Double> carregarArrecadacaoPecas(String caminhoArquivo) throws IOException {
        Workbook workbook = carregarPlanilha(caminhoArquivo);
        Sheet sheet = workbook.getSheetAt(0); // Preços das áreas
        Map<String, Integer> precos = new HashMap<>();
        precos.put("Plateia A", 40);
        precos.put("Plateia B", 60);
        precos.put("Frisa", 120);
        precos.put("Camarote", 80);
        precos.put("Balcão Nobre", 250);
        Map<String, Double> arrecadacaoPecas = new HashMap<>(); // A partir da segunda linha (índice 1)
        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);
            String peca = row.getCell(1).getStringCellValue(); // Coluna 2 (índice 1) armazena a peça escolhida
            String area = row.getCell(3).getStringCellValue(); // Coluna 4 (índice 3) armazena a área selecionada /
            // / Calcular o valor de cada ingresso com base na área
            int preco = precos.getOrDefault(area, 0);
            arrecadacaoPecas.put(peca, arrecadacaoPecas.getOrDefault(peca, 0.0) + preco);
        } return arrecadacaoPecas;
    }

    public String pecaMaisArrecadada(Map<String, Double> arrecadacaoPecas) {
        String pecaMaisArrecadada = null;
        double maiorArrecadacao = 0.0;
        for (Map.Entry<String, Double> entry : arrecadacaoPecas.entrySet()) {
            if (entry.getValue() > maiorArrecadacao) {
                pecaMaisArrecadada = entry.getKey();
                maiorArrecadacao = entry.getValue();
            }
        } return pecaMaisArrecadada + " com R$" + maiorArrecadacao;
    }

    public String pecaMenosArrecadada(Map<String, Double> arrecadacaoPecas) {
        String pecaMenosArrecadada = null;
        double menorArrecadacao = Double.MAX_VALUE;
        for (Map.Entry<String, Double> entry : arrecadacaoPecas.entrySet()) {
            if (entry.getValue() < menorArrecadacao) {
                pecaMenosArrecadada = entry.getKey();
                menorArrecadacao = entry.getValue();
            }
        } return pecaMenosArrecadada + " com R$" + menorArrecadacao;
    }

    public static double calcularReceitaMedia(String caminhoArquivo) throws IOException {
        Map<String, Double> arrecadacaoPecas = carregarArrecadacaoPecas(caminhoArquivo);
        double somaTotal = 0.0;
        for (double valor : arrecadacaoPecas.values()) {
            somaTotal += valor;
        }
        double receitaMedia = somaTotal / arrecadacaoPecas.size();
        return receitaMedia;
    }

    // Método para calcular a média arrecadada por peça
    public static void buscarValorMedioArrecadadoPorPeca(String caminhoArquivo) throws IOException {
        Workbook workbook = carregarPlanilha(caminhoArquivo);
        Sheet sheet = workbook.getSheetAt(0);

        // Preços das áreas
        Map<String, Integer> precos = new HashMap<>();
        precos.put("Plateia A", 40);
        precos.put("Plateia B", 60);
        precos.put("Frisa", 120);
        precos.put("Camarote", 80);
        precos.put("Balcão Nobre", 250);

        Map<String, Double> arrecadacaoPecas = new HashMap<>();
        Map<String, Integer> contadorPecas = new HashMap<>();

        // A partir da segunda linha (índice 1)
        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);
            String peca = row.getCell(1).getStringCellValue(); // Coluna 2 (índice 1) armazena a peça escolhida
            String area = row.getCell(3).getStringCellValue(); // Coluna 4 (índice 3) armazena a área selecionada

            // Calcular o valor de cada ingresso com base na área
            int preco = 0;
            if (area.contains("Plateia A")) {
                preco = precos.get("Plateia A");
            } else if (area.contains("Plateia B")) {
                preco = precos.get("Plateia B");
            } else if (area.contains("Frisa")) {
                preco = precos.get("Frisa");
            } else if (area.contains("Camarote")) {
                preco = precos.get("Camarote");
            } else if (area.contains("Balcão Nobre")) {
                preco = precos.get("Balcão Nobre");
            }

            // Somar o preço para o total arrecadado por peça
            arrecadacaoPecas.put(peca, arrecadacaoPecas.getOrDefault(peca, 0.0) + preco);
            // Contar quantos ingressos de cada peça foram vendidos
            contadorPecas.put(peca, contadorPecas.getOrDefault(peca, 0) + 1);
        }

        // Exibindo o valor médio arrecadado por peça
        for (Map.Entry<String, Double> entry : arrecadacaoPecas.entrySet()) {
            String peca = entry.getKey();
            double arrecadacaoTotal = entry.getValue();
            int totalIngressos = contadorPecas.get(peca);
            double mediaArrecadada = arrecadacaoTotal / totalIngressos;

            System.out.println("Média arrecadada por " + peca + ": R$" + mediaArrecadada);
        }
    }
}
