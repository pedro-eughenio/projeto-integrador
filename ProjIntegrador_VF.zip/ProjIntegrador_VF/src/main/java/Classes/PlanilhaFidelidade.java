/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
/**
 *
 * @author gaby
 */
public class PlanilhaFidelidade {
    
    String caminhoArquivo = "C:\\Users\\Aluno\\IdeaProjects\\NovoCodigoPI\\dados_fidelidade.xls";

        // Método para criar a planilha Excel com cabeçalho
        void criar() {
            HSSFWorkbook workbook = new HSSFWorkbook();  // Cria uma nova planilha Excel
            HSSFSheet sheet = workbook.createSheet("Cadastro");  // Cria uma aba chamada "Cadastro"

            // Cria o cabeçalho na primeira linha
            Row cabecalho = sheet.createRow(0);
            cabecalho.createCell(0).setCellValue("CPF");
            cabecalho.createCell(1).setCellValue("Nome");
            cabecalho.createCell(2).setCellValue("Telefone");
            cabecalho.createCell(3).setCellValue("Endereco");
            cabecalho.createCell(4).setCellValue("Data de Nascimento");

            // Escreve a planilha no arquivo
            try (FileOutputStream fileOut = new FileOutputStream(caminhoArquivo)) {
                workbook.write(fileOut);  // Escreve no arquivo
                System.out.println("Arquivo Excel criado com sucesso!");
            } catch (IOException e) {
                System.err.println("Erro ao criar o arquivo Excel: " + e.getMessage());
            }
        }

        // Método para escrever dados de um novo usuário na planilha Excel
        public void escrever(String cpf, String nome, String telefone, String endereco, String dataNascimento) {
            // Dados do cliente a serem gravados no arquivo
            String[] dadosCliente = {cpf, nome, telefone, endereco, dataNascimento};

            // Abre o arquivo existente para adicionar uma nova linha
            try (FileInputStream fileIn = new FileInputStream(caminhoArquivo)) {
                HSSFWorkbook workbook = new HSSFWorkbook(fileIn);
                HSSFSheet sheet = workbook.getSheet("Cadastro");  // Obtém a aba "Usuarios"

                // Encontra a última linha e cria uma nova
                int ultimaLinha = sheet.getPhysicalNumberOfRows();
                Row novaLinha = sheet.createRow(ultimaLinha);

                // Preenche as células da nova linha com os dados do cliente
                for (int i = 0; i < dadosCliente.length; i++) {
                    novaLinha.createCell(i).setCellValue(dadosCliente[i]);
                }

                // Salva as alterações no arquivo
                try (FileOutputStream fileOut = new FileOutputStream(caminhoArquivo)) {
                    workbook.write(fileOut);
                    System.out.println("Dados do usuário gravados com sucesso!");
                }

            } catch (IOException e) {
                System.err.println("Erro ao gravar dados no arquivo Excel: " + e.getMessage());
            }
        }

        // Método para verificar se o arquivo Excel existe, se não, criar
        public void checarExistencia() {
            File arquivo = new File(caminhoArquivo);
            if (!arquivo.exists()) {
                criar();  // Cria a planilha caso não exista
            } else {
                System.out.println("Arquivo Excel já existe.");
            }
        }

        // Método para verificar se um CPF já existe na planilha Excel
        public boolean checarCpf(String cpf) {
            try (FileInputStream fileIn = new FileInputStream(caminhoArquivo)) {
                HSSFWorkbook workbook = new HSSFWorkbook(fileIn);
                HSSFSheet sheet = workbook.getSheet("Cadastro");  // Obtém a aba "Usuarios"

                // Itera pelas linhas da planilha
                for (Row row : sheet) {
                    // O CPF está na primeira célula da linha (índice 0)
                    Cell cell = row.getCell(0);
                    if (cell != null && cell.getCellType() == CellType.STRING) {
                        String cpfEncontrado = cell.getStringCellValue().trim();
                        if (cpf.equals(cpfEncontrado)) {
                            return true;  // CPF encontrado
                        }
                    }
                }
            } catch (IOException e) {
                System.err.println("Erro ao ler o arquivo Excel: " + e.getMessage());
            }
            return false;  // CPF não encontrado
        }
}
